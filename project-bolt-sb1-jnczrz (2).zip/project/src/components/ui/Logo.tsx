import React from 'react';

export const Logo = ({ className = 'h-8' }: { className?: string }) => {
  return (
    <img 
      src="/rissala-tech-logo.png" 
      alt="RissalaTech" 
      className={className}
    />
  );
};