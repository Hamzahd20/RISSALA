import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  BarChart2, 
  Settings,
  MessageSquare,
  LogOut 
} from 'lucide-react';
import { Logo } from './ui/Logo';
import { cn } from '@/lib/utils';
import { siteConfig } from '@/config/site';

const Sidebar = () => {
  const location = useLocation();
  const navigation = siteConfig.mainNav;

  const getIcon = (title: string) => {
    switch (title) {
      case 'Dashboard': return LayoutDashboard;
      case 'Clients': return Users;
      case 'Policies': return FileText;
      case 'Communications': return MessageSquare;
      case 'Analytics': return BarChart2;
      case 'Settings': return Settings;
      default: return LayoutDashboard;
    }
  };

  return (
    <div className="hidden lg:flex lg:flex-shrink-0">
      <div className="flex flex-col w-64">
        <div className="flex flex-col flex-grow bg-primary-600 pt-5 pb-4 overflow-y-auto">
          <div className="flex items-center flex-shrink-0 px-4">
            <Logo className="h-8" />
          </div>
          <nav className="mt-8 flex-1 flex flex-col space-y-1" aria-label="Sidebar">
            {navigation.map((item) => {
              const Icon = getIcon(item.title);
              return (
                <Link
                  key={item.title}
                  to={item.href}
                  className={cn(
                    'flex items-center px-4 py-2 text-sm font-medium',
                    location.pathname === item.href
                      ? 'bg-primary-700 text-white'
                      : 'text-primary-100 hover:bg-primary-700'
                  )}
                >
                  <Icon className="mr-3 h-6 w-6" />
                  {item.title}
                </Link>
              );
            })}
          </nav>
          <div className="mt-auto">
            <button
              className="flex items-center px-4 py-2 text-sm font-medium text-primary-100 hover:bg-primary-700 w-full"
            >
              <LogOut className="mr-3 h-6 w-6" />
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;