import React from 'react';
import { useForm } from 'react-hook-form';
import { X } from 'lucide-react';
import { notificationService } from '../services/notifications';
import toast from 'react-hot-toast';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: {
    name: string;
    phone: string;
    policyNumber: string;
    expiryDate: string;
  };
}

interface NotificationForm {
  channel: 'sms' | 'whatsapp' | 'both';
  message: string;
}

const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  client,
}) => {
  const { register, handleSubmit } = useForm<NotificationForm>();

  const onSubmit = async (data: NotificationForm) => {
    try {
      await notificationService.sendPolicyRenewalReminder(
        client.phone,
        client.name,
        client.policyNumber,
        client.expiryDate,
        data.channel
      );
      toast.success('Notification sent successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to send notification');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Send Notification</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Notification Channel
            </label>
            <select
              {...register('channel')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="sms">SMS</option>
              <option value="whatsapp">WhatsApp</option>
              <option value="both">Both</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Preview
            </label>
            <div className="mt-1 p-3 bg-gray-50 rounded-md text-sm">
              Dear {client.name}, your policy {client.policyNumber} is due to expire on{' '}
              {new Date(client.expiryDate).toLocaleDateString()}. Please renew to
              maintain coverage.
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              Send Notification
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NotificationModal;