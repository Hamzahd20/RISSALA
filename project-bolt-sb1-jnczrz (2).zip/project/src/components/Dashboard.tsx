import React from 'react';
import { BarChart3, Users, Bell, Calendar } from 'lucide-react';
import ClientTable from './ClientTable';
import StatsCard from './StatsCard';
import RenewalChart from './RenewalChart';

const Dashboard = () => {
  const stats = [
    {
      title: 'Total Clients',
      value: '2,345',
      icon: Users,
      change: '+12.5%',
      changeType: 'positive'
    },
    {
      title: 'Pending Renewals',
      value: '42',
      icon: Calendar,
      change: '-8%',
      changeType: 'negative'
    },
    {
      title: 'Sent Notifications',
      value: '1,234',
      icon: Bell,
      change: '+23.1%',
      changeType: 'positive'
    },
    {
      title: 'Renewal Rate',
      value: '89%',
      icon: BarChart3,
      change: '+4.3%',
      changeType: 'positive'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <StatsCard key={stat.title} {...stat} />
        ))}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold mb-4">Renewal Trends</h2>
          <RenewalChart />
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold mb-4">Upcoming Renewals</h2>
          <div className="space-y-4">
            {/* Add upcoming renewals list here */}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm">
        <ClientTable />
      </div>
    </div>
  );
};

export default Dashboard;