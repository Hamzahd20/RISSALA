import React, { useState } from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { MoreVertical, Send } from 'lucide-react';
import { notificationService } from '../services/notifications';
import toast from 'react-hot-toast';

type Client = {
  id: string;
  name: string;
  phone: string;
  policyNumber: string;
  expiryDate: string;
  language: 'fr' | 'ar' | 'en';
  status: 'active' | 'pending' | 'expired';
};

const columnHelper = createColumnHelper<Client>();

const ClientTable = () => {
  const [sendingNotification, setSendingNotification] = useState<string | null>(null);

  const handleSendNotification = async (client: Client) => {
    try {
      setSendingNotification(client.id);
      await notificationService.sendPolicyExpiryReminder(
        client.phone,
        new Date(client.expiryDate),
        client.language
      );
      toast.success('Reminder sent successfully');
    } catch (error) {
      toast.error('Failed to send reminder');
    } finally {
      setSendingNotification(null);
    }
  };

  const columns = [
    columnHelper.accessor('name', {
      header: 'Client Name',
      cell: (info) => (
        <div className="font-medium text-gray-900">{info.getValue()}</div>
      ),
    }),
    columnHelper.accessor('phone', {
      header: 'Phone Number',
    }),
    columnHelper.accessor('policyNumber', {
      header: 'Policy Number',
    }),
    columnHelper.accessor('expiryDate', {
      header: 'Expiry Date',
      cell: (info) => (
        <div className="font-medium">
          {new Date(info.getValue()).toLocaleDateString()}
        </div>
      ),
    }),
    columnHelper.accessor('language', {
      header: 'Language',
      cell: (info) => (
        <span className="capitalize">{info.getValue()}</span>
      ),
    }),
    columnHelper.accessor('status', {
      header: 'Status',
      cell: (info) => {
        const status = info.getValue();
        const colors = {
          active: 'bg-green-100 text-green-800',
          pending: 'bg-yellow-100 text-yellow-800',
          expired: 'bg-red-100 text-red-800',
        };

        return (
          <span
            className={\`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium \${colors[status]}\`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </span>
        );
      },
    }),
    columnHelper.display({
      id: 'actions',
      cell: ({ row }) => (
        <div className="flex items-center space-x-3">
          <button
            onClick={() => handleSendNotification(row.original)}
            disabled={sendingNotification === row.original.id}
            className="text-gray-400 hover:text-gray-500 disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
          <button className="text-gray-400 hover:text-gray-500">
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      ),
    }),
  ];

  const data: Client[] = [
    {
      id: '1',
      name: 'John Smith',
      phone: '+212666123456',
      policyNumber: 'POL-2024-001',
      expiryDate: '2024-06-15',
      language: 'fr',
      status: 'active',
    },
    {
      id: '2',
      name: 'محمد أحمد',
      phone: '+212677123456',
      policyNumber: 'POL-2024-002',
      expiryDate: '2024-07-20',
      language: 'ar',
      status: 'pending',
    },
    // Add more sample data as needed
  ];

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <th
                  key={header.id}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {flexRender(
                    header.column.columnDef.header,
                    header.getContext()
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id}>
              {row.getVisibleCells().map((cell) => (
                <td
                  key={cell.id}
                  className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                >
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ClientTable;