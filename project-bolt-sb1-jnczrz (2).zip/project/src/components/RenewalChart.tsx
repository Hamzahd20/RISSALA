import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { month: 'Jan', renewals: 65 },
  { month: 'Feb', renewals: 59 },
  { month: 'Mar', renewals: 80 },
  { month: 'Apr', renewals: 81 },
  { month: 'May', renewals: 56 },
  { month: 'Jun', renewals: 55 },
  { month: 'Jul', renewals: 40 },
];

const RenewalChart = () => {
  return (
    <div className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Area
            type="monotone"
            dataKey="renewals"
            stroke="#3B82F6"
            fill="#93C5FD"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default RenewalChart;