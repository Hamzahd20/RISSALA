export const siteConfig = {
  name: 'InsureRemind',
  description: 'Insurance policy reminder and management system',
  mainNav: [
    { title: 'Dashboard', href: '/' },
    { title: 'Clients', href: '/clients' },
    { title: 'Policies', href: '/policies' },
    { title: 'Communications', href: '/communications' },
    { title: 'Analytics', href: '/analytics' },
    { title: 'Settings', href: '/settings' },
  ],
} as const;