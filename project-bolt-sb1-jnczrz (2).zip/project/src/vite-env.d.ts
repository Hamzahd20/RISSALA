/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SINCH_SERVICE_PLAN_ID: string
  readonly VITE_SINCH_API_TOKEN: string
  readonly VITE_SINCH_SENDER_ID: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}