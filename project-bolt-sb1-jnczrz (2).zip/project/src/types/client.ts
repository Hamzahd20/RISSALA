export interface Client {
  id: string;
  name: string;
  phone: string;
  policyNumber: string;
  expiryDate: string;
  language: 'fr' | 'ar' | 'en';
  status: 'active' | 'pending' | 'expired';
  email?: string;
  address?: string;
  notes?: string;
}