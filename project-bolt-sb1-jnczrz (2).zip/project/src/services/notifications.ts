import { SinchClient } from '@sinch/sdk-core';
import { SmsApi } from '@sinch/sdk-sms';
import { format } from 'date-fns';
import { fr, ar } from 'date-fns/locale';

interface NotificationConfig {
  servicePlanId: string;
  apiToken: string;
  senderId: string;
}

type Language = 'en' | 'fr' | 'ar';

class NotificationService {
  private smsApi: SmsApi;
  private config: NotificationConfig;

  constructor(config: NotificationConfig) {
    this.config = config;
    const client = new SinchClient({
      servicePlanId: config.servicePlanId,
      apiToken: config.apiToken,
    });

    this.smsApi = new SmsApi(client);
  }

  private getMessageTemplate(language: Language, expiryDate: Date, companyName: string = 'SANLAM ALKARIASSUR BOUZNIKA'): string {
    const dateLocales = {
      fr,
      ar,
      en: undefined
    };

    const formattedDate = format(expiryDate, 'dd/MM/yyyy', {
      locale: dateLocales[language]
    });

    const templates = {
      fr: `Bonjour,

Nous vous rappelons que votre assurance expire le ${formattedDate}.

Pour toute question ou assistance, n'hésitez pas à nous contacter.
0600016017
0701072221

Avec nos compliments,
${companyName}`,
      ar: `مرحباً

نود تذكيرك بأن تأمين الخاص بكم سينتهي في تاريخ ${formattedDate}.

لأي استفسار أو مساعدة، لا تتردد في الاتصال بنا.

مع تحياتنا،
${companyName}`,
      en: `Hello,

We would like to remind you that your insurance policy expires on ${formattedDate}.

For any questions or assistance, please don't hesitate to contact us.
0600016017
0701072221

Best regards,
${companyName}`
    };

    return templates[language];
  }

  async sendPolicyExpiryReminder(
    to: string,
    expiryDate: Date,
    language: Language = 'fr',
    companyName?: string
  ) {
    try {
      const message = this.getMessageTemplate(language, expiryDate, companyName);
      
      const response = await this.smsApi.batches.send({
        from: this.config.senderId,
        to: [to],
        body: message,
      });

      return {
        success: true,
        messageId: response.id,
        status: response.status
      };
    } catch (error) {
      console.error('SMS sending failed:', error);
      throw error;
    }
  }
}

// Initialize with the provided credentials
export const notificationService = new NotificationService({
  servicePlanId: '6f551b88f861401bbc9aab235694a0c0',
  apiToken: '9af2226fea2a4d469e6eb9f17deec93d',
  senderId: '+447418630997',
});